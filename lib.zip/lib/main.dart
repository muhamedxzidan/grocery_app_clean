import 'package:flutter/material.dart';
import 'package:grocery_app_clean/grocery_app.dart';

void main() {
  runApp(const GroceryApp());
}
