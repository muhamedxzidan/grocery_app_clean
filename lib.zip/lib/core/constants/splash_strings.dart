class SplashStrings {
  static const String splash1Title = "Buy Grocery";
  static const String splash1SubTitle =
      "Lorem ipsum dolor sit amet, consetetur \nsadipscing elitr, sed diam nonumy";
  static const String splash1Image = "assets/images/splash1.png";

  static const String splash2Title = "Fast Delivery";
  static const String splash2SubTitle =
      "Lorem ipsum dolor sit amet, consetetur \nsadipscing elitr, sed diam nonumy";
  static const String splash2Image = "assets/images/splash2.png";

  static const String splash3Title = "Enjoy Quality Food";
  static const String splash3SubTitle =
      "Lorem ipsum dolor sit amet, consetetur \nsadipscing elitr, sed diam nonumy";
  static const String splash3Image = "assets/images/splash3.png";

  static const String skipText = "Skip";
  static const String nextText = "Next";
}
